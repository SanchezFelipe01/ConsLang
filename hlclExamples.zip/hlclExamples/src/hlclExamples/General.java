package hlclExamples;

import com.variamos.hlcl.model.domains.BinaryDomain;
import com.variamos.hlcl.model.domains.IntervalDomain;
import com.variamos.hlcl.model.domains.RangeDomain;
import com.variamos.hlcl.model.expressions.HlclFactory;
import com.variamos.hlcl.model.expressions.Identifier;

public class General {
	private HlclFactory f= new HlclFactory();
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	public Identifier[] identifiers(String idBase) {
		Identifier [] ids= new Identifier[4];
		
		for (int i = 0; i < ids.length; i++) {
			ids[i]= f.newIdentifier(idBase+i);
		}
		return ids;
	}
	
	public void domains(Identifier [] ids) {
		//boolean
		BinaryDomain binD= new BinaryDomain(); 
		ids[0].setDomain(binD);
		//range
		
		RangeDomain rangeD= new RangeDomain(2, 8);
		ids[1].setDomain(binD);
		//set
		
		IntervalDomain interval= new IntervalDomain();
		interval.add(1);
		ids[2].setDomain(interval);
		//string
		
	}

}
