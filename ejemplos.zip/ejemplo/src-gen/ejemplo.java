
 import com.variamos.hlcl.model.expressions.HlclFactory;
 import com.variamos.hlcl.model.expressions.Identifier;
 import com.variamos.hlcl.model.domains.BinaryDomain;

public class ejemplo {
	
	public static void main(String[] args) {
		ejemplo obj = new ejemplo();
		obj.run();
	}
	
	public void run() {
		
		HlclFactory f = new HlclFactory();
		
		System.out.println("declaring  a  with domain org.xtext.hlcl.impl.RangeDomImpl@3a39c80d (start: 0, end: 1))");
		
		Identifier a = f.newIdentifier("a");
		//se declara un RangeDomain
		
		
				
		System.out.println("declaring  b  with domain org.xtext.hlcl.impl.RangeDomImpl@e1d0920 (start: 0, end: 1))");
		
		Identifier b = f.newIdentifier("b");
		//se declara un RangeDomain
		
		
				
		System.out.println("declaring  c  with domain org.xtext.hlcl.impl.SetDomImpl@32c69b5d (list: 1))");
		
		Identifier c = f.newIdentifier("c");
		//se declara un RangeDomain
		
		
				
		
	}
	
}
