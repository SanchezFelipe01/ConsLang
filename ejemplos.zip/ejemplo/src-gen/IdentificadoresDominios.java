
 import com.variamos.hlcl.model.expressions.HlclFactory;
 import com.variamos.hlcl.model.expressions.Identifier;
 import com.variamos.hlcl.model.domains.*;

public class IdentificadoresDominios {
	
	public static void main(String[] args) {
		IdentificadoresDominios obj = new IdentificadoresDominios();
		obj.run();
	}
	
	public void run() {
		
		HlclFactory f = new HlclFactory();
		
		System.out.println("declaring  a  with domain org.xtext.hlcl.impl.RangeDomImpl@6a5d19d2 (start: 1, end: 9))");
		
		Identifier a = f.newIdentifier("a");
		//se declara un RangeDomain
		RangeDomain aDom= new RangeDomain(1, 9);
		a.setDomain(aDom);
		
		
		
				
		System.out.println("declaring  b  with domain org.xtext.hlcl.impl.BoolDomImpl@5b1d2acf (dom: boolDomain))");
		
		Identifier b = f.newIdentifier("b");
		//se declara un boolDomain
		BinaryDomain bDom= new BinaryDomain();
		 b.setDomain(bDom);
		
		
				
		System.out.println("declaring  c  with domain org.xtext.hlcl.impl.SetDomImpl@3bb35c8b (list: [1, 2, 3, 4, 5]))");
		
		Identifier c = f.newIdentifier("c");
		//se declara un SetDomain	
		IntervalDomain cDom= new IntervalDomain();
		System.out.println(1);
		System.out.println(2);
		System.out.println(3);
		System.out.println(4);
		System.out.println(5);
		c.setDomain(cDom);
		
		
				
		
	}
	
}
